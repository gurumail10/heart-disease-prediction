# theming-showcase

This is an example app showcasing how to use themes in [Streamlit](https://streamlit.io/). See the app live [here](https://share.streamlit.io/streamlit/theming-showcase/main). For more info, check out our [docs](https://docs.streamlit.io/en/stable/main_concepts.html#themes) and [blog post](https://blog.streamlit.io/introducing-theming/).
